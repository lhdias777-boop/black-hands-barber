import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
async function main(){
  const services=[
    ['Cabelo',35],['Barba',30],['Pintura',15],['Relaxamento',15],['Pigmentação',15],['Pezinho',10],['Sobrancelha',10]
  ];
  for(const [name,price] of services){
    await prisma.service.upsert({where:{name:String(name)},update:{price:Number(price),active:true},create:{name:String(name),price:Number(price),active:true}});
  }
  for(const name of ['Black Hands 01','Black Hands 02']){
    await prisma.barber.upsert({where:{name},update:{active:true},create:{name,active:true}});
  }
  for(const [name,price] of [['Black',79],['Black Plus',99],['Black VIP',129]]){
    await prisma.subscriptionPlan.upsert({where:{name:String(name)},update:{price:Number(price),active:true},create:{name:String(name),price:Number(price),active:true}});
  }
}
main().catch(e=>{console.error(e);process.exit(1)}).finally(()=>prisma.$disconnect());
