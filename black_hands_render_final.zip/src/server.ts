import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import axios from 'axios';
import path from 'path';
import { z } from 'zod';
import { PrismaClient, PaymentMethod, PaymentStatus, BookingStatus, SubscriptionStatus } from '@prisma/client';

const prisma = new PrismaClient();
const app = express();
const PORT = Number(process.env.PORT || 3333);
const ASAAS_BASE_URL = process.env.ASAAS_BASE_URL || 'https://api-sandbox.asaas.com/v3';
const ASAAS_API_KEY = process.env.ASAAS_API_KEY || '';
const WEBHOOK_TOKEN = process.env.ASAAS_WEBHOOK_TOKEN || '';

app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('combined'));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(process.cwd(), 'public')));

const asaas = axios.create({ baseURL: ASAAS_BASE_URL, headers: { access_token: ASAAS_API_KEY, 'Content-Type':'application/json', 'User-Agent':'BlackHands/1.0 (Node.js; Asaas)' }, timeout: 15000 });

function money(v: unknown){ return Number(v); }
function dateOnly(d: Date){ return d.toISOString().slice(0,10); }

app.get('/api/health', async (_req,res)=>{
  const db = await prisma.$queryRaw`SELECT 1`;
  res.json({ok:true, database:!!db, asaasConfigured:!!ASAAS_API_KEY, environment: ASAAS_BASE_URL.includes('sandbox')?'sandbox':'production'});
});

app.get('/api/services', async (_req,res)=>res.json(await prisma.service.findMany({where:{active:true},orderBy:{name:'asc'}})));
app.get('/api/barbers', async (_req,res)=>res.json(await prisma.barber.findMany({where:{active:true},orderBy:{name:'asc'}})));

const customerSchema=z.object({name:z.string().min(2),phone:z.string().min(8),email:z.string().email().optional().or(z.literal(''))});
async function getOrCreateAsaasCustomer(data:{name:string;phone:string;email?:string}, localId:string){
  const local=await prisma.customer.findUnique({where:{id:localId}});
  if(local?.asaasId) return local.asaasId;
  const response=await asaas.post('/customers',{name:data.name,phone:data.phone,email:data.email||undefined,externalReference:localId});
  const asaasId=response.data.id as string;
  await prisma.customer.update({where:{id:localId},data:{asaasId}});
  return asaasId;
}

const bookingSchema=z.object({customer:customerSchema,serviceId:z.string(),barberId:z.string(),startsAt:z.string().datetime(),paymentMethod:z.enum(['PIX','CREDIT_CARD','UNDEFINED'])});
app.post('/api/bookings',async(req,res)=>{
  try{
    const input=bookingSchema.parse(req.body);
    const service=await prisma.service.findUnique({where:{id:input.serviceId}});
    const barber=await prisma.barber.findUnique({where:{id:input.barberId}});
    if(!service||!barber) return res.status(400).json({error:'Serviço ou barbeiro inválido'});
    const startsAt=new Date(input.startsAt);
    const conflict=await prisma.booking.findFirst({where:{barberId:barber.id,startsAt,status:{not:BookingStatus.CANCELLED}}});
    if(conflict) return res.status(409).json({error:'Este horário já foi reservado.'});
    const customer=await prisma.customer.create({data:{name:input.customer.name,phone:input.customer.phone,email:input.customer.email||null}});
    const booking=await prisma.booking.create({data:{customerId:customer.id,serviceId:service.id,barberId:barber.id,startsAt,amount:service.price}});
    const asaasCustomerId=await getOrCreateAsaasCustomer(input.customer,customer.id);
    const dueDate=new Date(startsAt.getTime());
    const payment=await asaas.post('/payments',{customer:asaasCustomerId,billingType:input.paymentMethod,value:money(service.price),dueDate:dateOnly(dueDate),description:`Black Hands - ${service.name}`,externalReference:booking.id});
    const p=payment.data;
    let pix:any=null;
    if(input.paymentMethod==='PIX'){
      try{ pix=(await asaas.get(`/payments/${p.id}/pixQrCode`)).data; }catch(e){ console.warn('Pix QR ainda não disponível',e); }
    }
    await prisma.booking.update({where:{id:booking.id},data:{asaasPaymentId:p.id}});
    await prisma.payment.create({data:{bookingId:booking.id,customerId:customer.id,asaasId:p.id,status:PaymentStatus.PENDING,method:input.paymentMethod as PaymentMethod,value:service.price,invoiceUrl:p.invoiceUrl||null,pixPayload:pix?.payload||null,pixEncodedImage:pix?.encodedImage||null,dueDate}});
    res.status(201).json({bookingId:booking.id,paymentId:p.id,status:p.status,invoiceUrl:p.invoiceUrl||null,pix});
  }catch(e:any){ console.error(e?.response?.data||e); res.status(400).json({error:e?.response?.data?.errors?.[0]?.description||e.message||'Não foi possível criar o agendamento'}); }
});

app.get('/api/bookings/:id',async(req,res)=>{
  const b=await prisma.booking.findUnique({where:{id:req.params.id},include:{customer:true,service:true,barber:true,payment:true}});
  if(!b) return res.status(404).json({error:'Agendamento não encontrado'});
  res.json(b);
});

const subscriptionSchema=z.object({customer:customerSchema,planId:z.string(),billingType:z.enum(['PIX','CREDIT_CARD','UNDEFINED'])});
app.post('/api/subscriptions',async(req,res)=>{
  try{
    const input=subscriptionSchema.parse(req.body);
    const plan=await prisma.subscriptionPlan.findUnique({where:{id:input.planId}}); if(!plan) return res.status(400).json({error:'Plano inválido'});
    const customer=await prisma.customer.create({data:{name:input.customer.name,phone:input.customer.phone,email:input.customer.email||null}});
    const asaasCustomerId=await getOrCreateAsaasCustomer(input.customer,customer.id);
    const next=new Date(); next.setDate(next.getDate()+1);
    const response=await asaas.post('/subscriptions',{customer:asaasCustomerId,billingType:input.billingType,value:money(plan.price),nextDueDate:dateOnly(next),cycle:'MONTHLY',description:`Black Hands Club - ${plan.name}`,externalReference:customer.id});
    const s=response.data;
    await prisma.subscription.create({data:{customerId:customer.id,planId:plan.id,asaasId:s.id,value:plan.price,nextDueDate:next,status:SubscriptionStatus.INACTIVE}});
    res.status(201).json({subscriptionId:s.id,status:s.status,nextDueDate:s.nextDueDate});
  }catch(e:any){console.error(e?.response?.data||e);res.status(400).json({error:e?.response?.data?.errors?.[0]?.description||e.message||'Não foi possível criar assinatura'});}
});

app.get('/api/admin/summary',async(_req,res)=>{
  const [bookings,pending,received,subs,customers]=await Promise.all([
    prisma.booking.count(),prisma.payment.count({where:{status:PaymentStatus.PENDING}}),prisma.payment.aggregate({where:{status:PaymentStatus.RECEIVED},_sum:{value:true}}),prisma.subscription.count({where:{status:SubscriptionStatus.ACTIVE}}),prisma.customer.count()
  ]);
  res.json({bookings,pendingPayments:pending,received:received._sum.value||0,activeSubscriptions:subs,customers});
});

app.post('/api/webhooks/asaas',async(req,res)=>{
  const token=req.header('asaas-access-token')||req.header('x-asaas-access-token');
  if(WEBHOOK_TOKEN && token!==WEBHOOK_TOKEN) return res.status(401).json({error:'unauthorized'});
  const body=req.body; const eventId=body.id || `${body.event}-${body.payment?.id||body.subscription?.id||Date.now()}`;
  try{
    const exists=await prisma.webhookEvent.findUnique({where:{asaasEventId:String(eventId)}}); if(exists) return res.status(200).json({ok:true,duplicate:true});
    await prisma.webhookEvent.create({data:{asaasEventId:String(eventId),event:String(body.event||'UNKNOWN'),payload:body,processed:false}});
    const payment=body.payment;
    if(payment?.id){
      let status:PaymentStatus|undefined;
      if(['PAYMENT_RECEIVED','PAYMENT_CONFIRMED'].includes(body.event)) status=PaymentStatus.RECEIVED;
      else if(body.event==='PAYMENT_OVERDUE') status=PaymentStatus.OVERDUE;
      else if(body.event==='PAYMENT_REFUNDED') status=PaymentStatus.REFUNDED;
      else if(['PAYMENT_DELETED','PAYMENT_CREDIT_CARD_CAPTURE_REFUSED'].includes(body.event)) status=PaymentStatus.CANCELLED;
      if(status){
        const p=await prisma.payment.findUnique({where:{asaasId:payment.id}});
        if(p){ await prisma.payment.update({where:{id:p.id},data:{status,rawStatus:payment.status||body.event}}); if(p.bookingId && status===PaymentStatus.RECEIVED) await prisma.booking.update({where:{id:p.bookingId},data:{status:BookingStatus.CONFIRMED}}); }
      }
    }
    const subscription=body.subscription;
    if(subscription?.id){
      let status:SubscriptionStatus|undefined;
      if(['SUBSCRIPTION_CREATED','SUBSCRIPTION_UPDATED','PAYMENT_RECEIVED'].includes(body.event)) status=SubscriptionStatus.ACTIVE;
      if(['SUBSCRIPTION_INACTIVATED','SUBSCRIPTION_DELETED'].includes(body.event)) status=SubscriptionStatus.INACTIVE;
      if(status){await prisma.subscription.updateMany({where:{asaasId:subscription.id},data:{status,nextDueDate:subscription.nextDueDate?new Date(subscription.nextDueDate):undefined}});}
    }
    await prisma.webhookEvent.update({where:{asaasEventId:String(eventId)},data:{processed:true}});
    res.status(200).json({ok:true});
  }catch(e){console.error(e);res.status(500).json({error:'webhook processing failed'});}
});

app.use((req,res,next)=>{ if(req.method==='GET' && !req.path.startsWith('/api/')) return res.sendFile(path.join(process.cwd(),'public','index.html')); next(); });
app.listen(PORT,()=>console.log(`Black Hands rodando em http://localhost:${PORT}`));
