# Black Hands no celular — Render

Você não precisa instalar Node.js ou Docker no iPhone. O caminho recomendado é:

**iPhone → GitHub → Render → Black Hands → Asaas Sandbox**

No Render, você só precisa informar os segredos quando solicitado. Nunca envie a chave da Asaas no chat.
